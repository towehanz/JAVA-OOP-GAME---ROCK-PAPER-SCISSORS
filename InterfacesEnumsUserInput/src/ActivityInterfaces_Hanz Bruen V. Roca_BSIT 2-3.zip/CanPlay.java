public interface CanPlay {

    public abstract RockPaperScissors pickWeapon();
    public abstract void systemMsg();

}